#include <msp430.h>
#include <driverlib.h>
#include "LedDriver.h"

unsigned char SW1_interruptFlag_ = 0;
unsigned char SW2_interruptFlag_ = 0;
unsigned char rates[] = {3, 10, 30}; //rates is the name of the array; global

#pragma vector = PORT1_VECTOR
__interrupt void P1_ISR(void)
  
{  
    switch(__even_in_range(P1IV,P1IV_P1IFG7)) 
    {
  case P1IV_P1IFG3: //switch 1 sent the interrupt signal
    SW1_interruptFlag_ = 1;
    GPIO_clearInterrupt(GPIO_PORT_P1, GPIO_PIN3);
    break;
    
  case P1IV_P1IFG4:  //switch 2 sent the interrupt signal
    SW2_interruptFlag_ = 1;
    GPIO_clearInterrupt(GPIO_PORT_P1, GPIO_PIN4);
    break;
    }
}
  


int main(void)
{
  
  //DEFAULT MCLK = 1MHz//
  
  unsigned int i = 0;
  unsigned char dialValue = 0x01; 
  unsigned int count = 0;
  unsigned int maxPeople =5;
  bool SwitchDirection = false;
  unsigned char rate_ = 1; //rate_ is the variable we use to cycle through the array; local to main()
  
  WDTCTL = WDTPW | WDTHOLD;             //STOP WATCHDOG TIMER//
  
  initialiseLedDial();
  
  //CONFIGURES BUTTON S1 AND S2 INTERRUPT
  GPIO_selectInterruptEdge(GPIO_PORT_P1, GPIO_PIN3 | GPIO_PIN4, GPIO_HIGH_TO_LOW_TRANSITION);
  GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P1, GPIO_PIN3 | GPIO_PIN4);
  GPIO_clearInterrupt(GPIO_PORT_P1, GPIO_PIN3 | GPIO_PIN4);
  GPIO_enableInterrupt(GPIO_PORT_P1, GPIO_PIN3 | GPIO_PIN4);
  
  //DISABLES THE GPIO POWER-ON DEFAULT HIGH IMPEDENCE MODE//
  //TO ACTIVATE PREVIOUSLY CONFIGURED PORT SETTINGS//
  
  
  PMM_unlockLPM5();
  
  __enable_interrupt();
  Init_LCD();
  
  while(1)
  {
    displayscrolltext("HI DEAN");
    if(SW1_interruptFlag_)
    {
      count = count+1;
    // SwitchDirection = !SwitchDirection;
      __delay_cycles(100000); //debouncing delay
      SW1_interruptFlag_ = 0;
      
      
    
    switch(count)
    {
    case 0: clearLCD();showChar('0',pos3);break;
    case 1: clearLCD();showChar('1',pos3);break;
    case 2: clearLCD();showChar('2',pos3);break;
    case 3: clearLCD();showChar('3',pos3);break;
    case 4: clearLCD();showChar('4',pos3);break;
    case 5: clearLCD();showChar('5',pos3);break;
    }
      
    }
    
    if(SW2_interruptFlag_)
    {
      count = count-1;
     // rate_ = rate_ +1; //increase rate_ -> cycle through rates[] array
     // if(3== rate_) //resets to original speed setting after cycling through 3
      //  rate_ = 0;
      
      __delay_cycles(100000); //debouncing delay
      SW2_interruptFlag_ = 0;
    }
    
    //Update value 
    if(count == maxPeople) //occupancy limit reahced
      {
          dialValue = dialValue; // Stop cycling
          
          if(0x00 == dialValue) // Set the led back at led 1
             dialValue = 0x01;
      }
      else if (count > maxPeople) //occupancy limit exceeded
      {
        dialValue = dialValue / 0x02; // Cycle anticlockwise
           if(0x00 == dialValue) // Set the led back at Led 2
             dialValue = 0x80;
      }
   
     else //count<maxPeople
      {
          dialValue = dialValue * 0x02; // cycle clockwise
          
          if(0x00 == dialValue) // Set the led back at led 1
             dialValue = 0x01;
      }
    
    
    
    
    
    //SET VALUE//
    setLedDial(dialValue);
    
    /** This is how we vary the speed*/
   //Refresh display (10 times for each position)
    for(i = 0; i < rates[rate_]; i++) // Either 3, 10 or 30, as in rates[] array
      refreshLedDial();



  }
}
